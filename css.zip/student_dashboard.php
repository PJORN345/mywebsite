<?php
session_start();
include 'db.php';

// Ensure only students can access
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'student') {
    header("Location: login.php");
    exit();
}

$student_id = $_SESSION['user_id'];

// Fetch student details
$stmt = $conn->prepare("SELECT name, membership_type FROM students WHERE id = ?");
$stmt->bind_param("i", $student_id);
$stmt->execute();
$student = $stmt->get_result()->fetch_assoc();

// Fetch attendance records
$attendance = $conn->prepare("SELECT check_in, check_out FROM attendance WHERE student_id = ?");
$attendance->bind_param("i", $student_id);
$attendance->execute();
$attendance_records = $attendance->get_result();

// Handle feedback submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['feedback'])) {
    $feedback = $_POST['feedback'];
    $stmt = $conn->prepare("INSERT INTO feedback (student_id, message) VALUES (?, ?)");
    $stmt->bind_param("is", $student_id, $feedback);
    if ($stmt->execute()) {
        echo "<script>alert('Feedback submitted successfully');</script>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Student Dashboard</title>
    <link rel="stylesheet" type="text/css" href="student.css">
</head>
<body>
    <h2>Welcome, <?php echo $student['name']; ?></h2>
    <p>Membership Type: <?php echo $student['membership_type']; ?></p>
    
    <h3>Your Attendance</h3>
    <table border="1">
        <tr>
            <th>Check-in</th>
            <th>Check-out</th>
        </tr>
        <?php while ($row = $attendance_records->fetch_assoc()) { ?>
            <tr>
                <td><?php echo $row['check_in']; ?></td>
                <td><?php echo $row['check_out'] ? $row['check_out'] : 'Still Checked-in'; ?></td>
            </tr>
        <?php } ?>
    </table>
    
    <h3>Submit Feedback</h3>
    <form method="POST" action="">
        <textarea name="feedback" required></textarea>
        <button type="submit">Submit</button>
    </form>
    
    <br>
    <a href="logout.php">Logout</a>
</body>
</html>
