<?php
session_start();
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $role = $_POST['role'];

    if ($role == 'student') {
        $membership_type = $_POST['membership_type'];
        $stmt = $conn->prepare("INSERT INTO students (name, email, password, membership_type) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $name, $email, $password, $membership_type);
    } elseif ($role == 'admin') {
        $stmt = $conn->prepare("INSERT INTO admins (email, password) VALUES (?, ?)");
        $stmt->bind_param("ss", $email, $password);
    }

    if ($stmt->execute()) {
        echo "<script>alert('Registration successful! You can now login.'); window.location='login.php';</script>";
    } else {
        echo "<script>alert('Error occurred. Please try again.');</script>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Register</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <h2>Register</h2>
    <form method="POST" action="">
        <label>Name:</label>
        <input type="text" name="name" required>
        
        <label>Email:</label>
        <input type="email" name="email" required>
        
        <label>Password:</label>
        <input type="password" name="password" required>
        
        <label>Role:</label>
        <select name="role" required onchange="toggleMembership(this.value)">
            <option value="student">Student</option>
            <option value="admin">Admin</option>
        </select>
        
        <div id="membership" style="display:block;">
            <label>Membership Type:</label>
            <select name="membership_type">
                <option value="Monthly">Monthly</option>
                <option value="Quarterly">Quarterly</option>
                <option value="Yearly">Yearly</option>
            </select>
        </div>
        
        <button type="submit">Register</button>
    </form>
    <br>
    <a href="login.php">Already have an account? Login here.</a>
    
    <script>
        function toggleMembership(role) {
            document.getElementById('membership').style.display = (role === 'student') ? 'block' : 'none';
        }
    </script>
</body>
</html>
